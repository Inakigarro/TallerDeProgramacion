﻿using System;

namespace Ejercicio_3
{
    class Ejercicio3
    {
        
        static void Main()
        {
            InterfazEj3 interfaz = new InterfazEj3();
            interfaz.MenuPrincipal();
        }
    }
}
