﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Ejercicio_1
{
    class Ejercicio1
    {
        static void Main()
        {
            InterfazEj1 interfazMenu = new InterfazEj1();
            interfazMenu.MenuPrincipal();
        }
    }
}
