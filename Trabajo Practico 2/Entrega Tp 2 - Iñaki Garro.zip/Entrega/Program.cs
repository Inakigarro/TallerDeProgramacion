﻿using System;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            InterfazEj2 interfaz = new InterfazEj2();
            interfaz.MenuPrincipal();
        }
    }
}
